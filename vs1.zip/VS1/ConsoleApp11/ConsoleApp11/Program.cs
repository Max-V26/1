﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Задание 1
            //int[] mas = new int[8];
            //for (int i = 0; i < 8; i++)
            //{
            //    Console.Write($"mas[{i}] = ");
            //    mas[i] = int.Parse(Console.ReadLine());
            //}
            //Задание 2
            //int[] mas = new int[8] { 1, -1, 2, -2, 3, -3, 4, -4 };
            //for (int i = 0; i < 8; i++)
            //{
            //    if (mas[i] > 0)
            //    {
            //        Console.WriteLine(mas[i]);
            //    }
            //}
            //Задание 3
            //int[] mas = new int[] { -7, 10, 5, 16, -4, 18 };
            //for (int i = 5; i >= 0; i--)
            //{
            //    Console.WriteLine($"{mas[i]}");
            //}
            //Задание 4
            //Random ran = new Random();
            //int[] mas = new int[12];
            //for (int i = 0; i < 12; i++)
            //{
            //    mas[i] = ran.Next(163, 191);
            //}
            //foreach (int elem in mas)
            //{
            //    Console.WriteLine($"Рост человека = {elem} см");
            //}
            Console.ReadKey();
        }
    }
}
